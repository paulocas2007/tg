SoftSPI
=======

Software SPI class for Arduino
